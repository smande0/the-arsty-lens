# B649-Project1

Project 1: Basic Statistics with Hadoop

The idea of this project is to get started with Hadoop and the MapReduce concept. This problem is similar to WordCount except that you will be computing the basic statistics such as min, max, average, and standard deviation of a given data set.   The input to the program will be a text file carrying exactly one floating point number per line. The output should include min, max, average, and standard deviation of these numbers. 


