rm -rf classes
rm basicstats.jar
rm -rf output
rm $HADOOP_HOME/bin/basicstats.jar 
rm $HADOOP_HOME-standalone/bin/basicstats.jar 

