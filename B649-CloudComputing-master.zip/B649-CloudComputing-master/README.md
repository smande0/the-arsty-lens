# B649-CloudComputing

- Project1 - Basic statistics with Hadoop MapReduce

- Project2 - PageRank algorithm with MapReduce